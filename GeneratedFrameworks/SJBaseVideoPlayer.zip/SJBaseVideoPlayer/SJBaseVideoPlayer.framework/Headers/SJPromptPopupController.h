//
//  SJPromptPopupController.h
//  Pods
//
//  Created by 畅三江 on 2019/7/12.
//

#import "SJPromptPopupControllerDefines.h"

NS_ASSUME_NONNULL_BEGIN

@interface SJPromptPopupController : NSObject<SJPromptPopupController>

@end

NS_ASSUME_NONNULL_END
