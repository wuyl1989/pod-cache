//
//  SJPrompt.h
//  SJPromptProject
//
//  Created by 畅三江 on 2017/9/26.
//  Copyright © 2017年 changsanjiang. All rights reserved.
//

#import "SJPromptDefines.h"

NS_ASSUME_NONNULL_BEGIN
@interface SJPrompt : NSObject<SJPromptProtocol>

@end
NS_ASSUME_NONNULL_END
