//
//  SJFlipTransitionManager.h
//  SJVideoPlayerProject
//
//  Created by 畅三江 on 2018/2/2.
//  Copyright © 2018年 changsanjiang. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "SJFlipTransitionManagerDefines.h"

NS_ASSUME_NONNULL_BEGIN
@interface SJFlipTransitionManager : NSObject<SJFlipTransitionManager>

@end
NS_ASSUME_NONNULL_END
