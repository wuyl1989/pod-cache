//
//  SJClipsCommonViewLayer.h
//  SJVideoPlayer
//
//  Created by 畅三江 on 2019/1/20.
//  Copyright © 2019 畅三江. All rights reserved.
//

#import <QuartzCore/QuartzCore.h>

NS_ASSUME_NONNULL_BEGIN

@interface SJClipsCommonViewLayer : CALayer

@end

NS_ASSUME_NONNULL_END
