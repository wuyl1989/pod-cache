//
//  SJSpeedupPlaybackPopupView.h
//  Pods
//
//  Created by BlueDancer on 2020/2/21.
//

#import <UIKit/UIKit.h>
#import "SJSpeedupPlaybackPopupViewDefines.h"

NS_ASSUME_NONNULL_BEGIN
@interface SJSpeedupPlaybackPopupView : UIView<SJSpeedupPlaybackPopupView>
@property (nonatomic) CGFloat rate;
@end
NS_ASSUME_NONNULL_END
