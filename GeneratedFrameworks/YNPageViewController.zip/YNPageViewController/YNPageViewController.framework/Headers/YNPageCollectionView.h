//
//  YNPageCollectionView.h
//  YNPageViewController
//
//  Created by ZYN on 2018/7/14.
//  Copyright © 2018年 yongneng. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface YNPageCollectionView : UICollectionView

@end
