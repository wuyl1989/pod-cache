//
//  YNPageHeaderScrollView.h
//  YNPageViewController
//
//  Created by ZYN on 2018/5/25.
//  Copyright © 2018年 yongneng. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "YNPageScrollView.h"

@interface YNPageHeaderScrollView : YNPageScrollView

@end
