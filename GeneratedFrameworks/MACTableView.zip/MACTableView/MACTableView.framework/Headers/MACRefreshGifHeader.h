//
//  MACRefreshGifHeader.h
//  MACTableView
//  https://github.com/azheng51714/MACTableView
//  Created by MacKun on 16/10/21.
//  Copyright © 2016年 MacKun All rights reserved.
//

#import <MJRefresh/MJRefresh.h>

FOUNDATION_EXTERN NSString *className;
@interface MACRefreshGifHeader : MJRefreshGifHeader

+ (void)registerMACRefresh;


@end
