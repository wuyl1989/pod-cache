//
//  TZGifPhotoPreviewController.h
//  TZImagePickerController
//
//  Created by ttouch on 2016/12/13.
//  Copyright © 2016年 谭真. All rights reserved.
//

#import <UIKit/UIKit.h>

@class TZAssetModel;
@interface TZGifPhotoPreviewController : UIViewController

@property (nonatomic, strong) TZAssetModel *model;

@end
