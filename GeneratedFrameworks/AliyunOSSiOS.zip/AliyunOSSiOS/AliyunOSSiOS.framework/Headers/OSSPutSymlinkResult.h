//
//  OSSPutSymlinkResult.h
//  AliyunOSSSDK
//
//  Created by huaixu on 2018/8/1.
//  Copyright © 2018年 aliyun. All rights reserved.
//

#import "OSSResult.h"

@interface OSSPutSymlinkResult : OSSResult

@end
