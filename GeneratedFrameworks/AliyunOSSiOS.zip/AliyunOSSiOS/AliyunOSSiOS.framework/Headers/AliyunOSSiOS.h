//
//  AliyunOSSiOS.h
//  AliyunOSSiOS
//
//  Created by xuyecan on 28/11/2016.
//  Copyright © 2016 xuyecan. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for AliyunOSSiOS.
FOUNDATION_EXPORT double AliyunOSSiOSVersionNumber;

//! Project version string for AliyunOSSiOS.
FOUNDATION_EXPORT const unsigned char AliyunOSSiOSVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <AliyunOSSiOS/PublicHeader.h>

#import "OSSService.h"
#import "OSSCompat.h"
