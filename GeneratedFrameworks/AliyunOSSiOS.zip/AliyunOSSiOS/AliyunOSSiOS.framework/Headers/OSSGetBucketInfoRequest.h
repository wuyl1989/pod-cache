//
//  OSSGetBucketInfoRequest.h
//  AliyunOSSSDK
//
//  Created by huaixu on 2018/7/10.
//  Copyright © 2018年 aliyun. All rights reserved.
//

#import "OSSRequest.h"

@interface OSSGetBucketInfoRequest : OSSRequest

@property (nonatomic, copy) NSString *bucketName;

@end
